
-- SUMMARY --

This small module provides a field formatter that displays a text field
as trimmed text with "read more" link.

-- INSTALLATION --

* Put the module in your drupal modules directory and enable it in
  admin/modules.
